package rss.hyesoo.rss;


public interface MyObserver {
     public abstract void updateUI();
}

