/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package coffeemachine;

/**
 *
 * @author WONSEOB
 */
public class Main {

    public static void main(String[] args) {

        CoffeeMachine yummycoffee;
        yummycoffee = new CoffeeMachine();
        yummycoffee.powerOnOff();
        yummycoffee.fillBeansTank(2000);
        yummycoffee.fillWaterTank(3000);
        yummycoffee.makeRegularcoffee();
        yummycoffee.makeEspressocoffee();
        yummycoffee.makeRegularcoffee();
        yummycoffee.makeEspressocoffee();
        yummycoffee.makeRegularcoffee();
        yummycoffee.makeEspressocoffee();
        yummycoffee.makeRegularcoffee();
        yummycoffee.makeEspressocoffee();
        yummycoffee.makeRegularcoffee();
        yummycoffee.powerOnOff();
        yummycoffee.powerOnOff();
        yummycoffee.makeEspressocoffee();
        yummycoffee.makeRegularcoffee();
        yummycoffee.makeEspressocoffee();
        yummycoffee.makeRegularcoffee();
        yummycoffee.powerOnOff();
        yummycoffee.powerOnOff();
        yummycoffee.makeEspressocoffee();
        yummycoffee.makeRegularcoffee();
        yummycoffee.makeEspressocoffee();
        yummycoffee.makeEspressocoffee();
        yummycoffee.makeRegularcoffee();
        yummycoffee.makeEspressocoffee();
        yummycoffee.makeEspressocoffee();
        yummycoffee.makeRegularcoffee();
        yummycoffee.makeEspressocoffee();
        yummycoffee.powerOnOff();
    }
}
