package ChatSever1403729;

/**
 *
 * @author HyeSoo
 */
public interface HistoryObserver {
    void newEntry(ChatEntry c);
}
