import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;


public class DogHobbyist {
	private DogFlock dogs;

	public void go() {
		dogs = new DogFlock("John");
		
		dogs.add(new Dog("Barkly", 12));
		dogs.add(new Dog("Xena", 10));
		dogs.add(new Dog("Wimpy", 6));
		dogs.add(new Dog("Sampy", 8));
		
		printDogs();
		saveDogs();
		
		dogs = new DogFlock("John");
		printDogs();
		
		restoreDogs();
		printDogs();
	}

	private void restoreDogs() {
		try {
			FileInputStream in = new FileInputStream("dogsmain.ser");
			ObjectInputStream obin = new ObjectInputStream(in);
			dogs = (DogFlock)obin.readObject();
			obin.close();
		} catch (FileNotFoundException e) {
			System.out.println("Could not open dogsmain.ser");
			e.printStackTrace();
		} catch (IOException e) {
			System.out.println("Error reading file");
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			System.out.println("Error reading object");
			e.printStackTrace();
		}
	}

	private void saveDogs() {
		try {
			FileOutputStream out = new FileOutputStream("dogsmain.ser");
			ObjectOutputStream obout = new ObjectOutputStream(out);
			obout.writeObject(dogs);
			obout.close();
		} catch (FileNotFoundException e) {
			System.out.println("Could not open dogsmain.ser");
			e.printStackTrace();
		} catch (IOException e) {
			System.out.println("Error writing into file");
			e.printStackTrace();
		}
	}
	
	public void printDogs() {
		System.out.println(dogs.getOwner() + " has " + dogs.getDogs().size() + " dogs:");
		for(Dog d: dogs.getDogs()) {
			System.out.println(d.getName() + ", " + d.getWeight());
		}
		System.out.println();
	}

}

