import java.io.Serializable;


public class Dog implements Serializable {
	private static final long serialVersionUID = 1L;
	
	private int weight;
	private String name;

	public Dog(String name, int weight) {
		this.weight = weight;
		this.name = name;
	}
	
	public int getWeight() {
		return this.weight;
	}
	
	public String getName() {
		return this.name;
	}
}
