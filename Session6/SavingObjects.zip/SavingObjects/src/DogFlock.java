import java.io.Serializable;
import java.util.ArrayList;

public class DogFlock implements Serializable {
	private static final long serialVersionUID = 1L;
	
	private String owner;
	private ArrayList<Dog> dogs;
	
	public DogFlock(String owner) {
		this.owner = owner;
		this.dogs = new ArrayList<Dog>();
	}
	
	public String getOwner() {
		return this.owner;
	}
	
	public ArrayList<Dog> getDogs() {
		return dogs;
	}
	
	public boolean add(Dog d) {
		return dogs.add(d);
	}
}
